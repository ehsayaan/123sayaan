<?php
header("location: ".$_GET['u']);
?>
